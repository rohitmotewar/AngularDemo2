import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SeekerrequirementComponent } from './components/seekerrequirement/seekerrequirement.component';
import { RequirementlistComponent } from './components/requirementlist/requirementlist.component';
import { HttpClientModule } from '@angular/common/http';
import { AddrequirementComponent } from './components/addrequirement/addrequirement.component';
import { UpdatereqComponent } from './components/updatereq/updatereq.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { UserregistrationComponent } from './components/userregistration/userregistration.component';
import { LoginComponent } from './components/login/login.component';
import { SeekerhomeComponent } from './components/seekerhome/seekerhome.component';
import { ProviderhomeComponent } from './components/providerhome/providerhome.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { SeekerprofileComponent } from './components/seekerprofile/seekerprofile.component';
import { ProviderprofileComponent } from './components/providerprofile/providerprofile.component';
import { UpdateseekerprofileComponent } from './components/updateseekerprofile/updateseekerprofile.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { UpdateproviderprofileComponent } from './components/updateproviderprofile/updateproviderprofile.component';
import { ViewallrequirementsComponent } from './components/viewallrequirements/viewallrequirements.component';
import { SeekerlistComponent } from './components/seekerlist/seekerlist.component';
import { ProviderlistComponent } from './components/providerlist/providerlist.component';
import { ManagerequirementComponent } from './components/managerequirement/managerequirement.component';
import { AdminprofileComponent } from './components/adminprofile/adminprofile.component';
import { UpdateadminprofileComponent } from './components/updateadminprofile/updateadminprofile.component';
import { ViwmyrequirementsComponent } from './components/viwmyrequirements/viwmyrequirements.component';

@NgModule({
  declarations: [
    AppComponent,
    SeekerrequirementComponent,
    RequirementlistComponent,
    AddrequirementComponent,
    UpdatereqComponent,
    HomepageComponent,
    UserregistrationComponent,
    LoginComponent,
    SeekerhomeComponent,
    ProviderhomeComponent,
    AdminhomeComponent,
    SeekerprofileComponent,
    ProviderprofileComponent,
    UpdateseekerprofileComponent,
    ContactusComponent,
    AboutusComponent,
    UpdateproviderprofileComponent,
    ViewallrequirementsComponent,
    SeekerlistComponent,
    ProviderlistComponent,
    ManagerequirementComponent,
    AdminprofileComponent,
    UpdateadminprofileComponent,
    ViwmyrequirementsComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
