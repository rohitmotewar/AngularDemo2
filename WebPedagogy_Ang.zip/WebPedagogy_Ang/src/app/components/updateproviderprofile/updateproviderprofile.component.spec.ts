import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateproviderprofileComponent } from './updateproviderprofile.component';

describe('UpdateproviderprofileComponent', () => {
  let component: UpdateproviderprofileComponent;
  let fixture: ComponentFixture<UpdateproviderprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateproviderprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateproviderprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
