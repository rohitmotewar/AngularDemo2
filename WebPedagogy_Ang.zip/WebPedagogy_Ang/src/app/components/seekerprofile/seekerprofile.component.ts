import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-seekerprofile',
  templateUrl: './seekerprofile.component.html',
  styleUrls: ['./seekerprofile.component.css']
})
export class SeekerprofileComponent implements OnInit {

  sData: Userreg;

  constructor(private loginService: LoginuserService, private router: Router) { }

  ngOnInit() {
    this.loginService.currenMessage.subscribe(
      (data) => {
        this.sData = data;

      },
      (err) => console.log('error occured')

    )

  }


  updateSeeker(seeker: Userreg) {
    //alert("email is" + seeker.email)
    this.loginService.sendusertoHome(seeker);
    this.router.navigate(['/updateseeker']);
  }

}


