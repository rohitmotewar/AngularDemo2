import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Seekerrequirement2 } from 'src/app/models/seekerrequirement2';
import { UpdatereqService } from 'src/app/services/updatereq.service';
import { SeekerrequirementService } from 'src/app/services/seekerrequirement.service';

@Component({
  selector: 'app-updatereq',
  templateUrl: './updatereq.component.html',
  styleUrls: ['./updatereq.component.css']
})
export class UpdatereqComponent implements OnInit {
  message: string;
  selectedRequirement: Seekerrequirement2;
  constructor(private updateService: UpdatereqService, private rService: SeekerrequirementService, private router: Router) { }

  ngOnInit() {
    this.updateService.currentRequirement.subscribe(seekerrequirement => this.selectedRequirement = seekerrequirement);
    alert(this.selectedRequirement.requirementId + " in Update");

  }

  updateRequirement(): void {
    alert("Update Requirement with Req.ID : " + this.selectedRequirement.requirementId);
    this.rService.updateRequirement(this.selectedRequirement)
      .subscribe(data => {
        alert("Requirement updated successfully.")
        this.router.navigate(["/requirementlist"]);
      });

  }

  cancelButton(): void {
    this.router.navigate(['/requirementlist'])
  };
}
