import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeekerrequirementComponent } from './seekerrequirement.component';

describe('SeekerrequirementComponent', () => {
  let component: SeekerrequirementComponent;
  let fixture: ComponentFixture<SeekerrequirementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeekerrequirementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeekerrequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
