import { Component, OnInit } from '@angular/core';
import { UserregService } from 'src/app/services/userreg.service';
import { Router } from '@angular/router';
import { Userreg } from 'src/app/models/userreg';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {

  userreg: Userreg = new Userreg();
  selectedValue: string = '';

  userForm: FormGroup = new FormGroup(
    {
      role: new FormControl("", [Validators.required]),
      firstname: new FormControl("", [Validators.required]),
      lastname: new FormControl("", [Validators.required]),
      dob: new FormControl(""),
      phoneNo: new FormControl("", [Validators.required, Validators.minLength(10)]),
      email: new FormControl("", [Validators.required, Validators.email]),
      companyname: new FormControl(""),
      password: new FormControl("", [Validators.required, Validators.minLength(6)]),
      street: new FormControl(""),
      area: new FormControl(""),
      city: new FormControl(""),
      state: new FormControl(""),
      country: new FormControl(""),
      pancardNo: new FormControl(""),
      gstNo: new FormControl(""),
      subscription: new FormControl(""),
      provider_type: new FormControl("")


    }, { updateOn: 'change' });


  constructor(private userservice: UserregService, private router: Router) { }

  ngOnInit() {
  }


  addUser(): void {
    if (this.userForm.valid) {

      this.userservice.adduser(this.userreg).subscribe
        (data => {
          alert("User Registered Successfully")
          this.router.navigate(['/login'])
        });
    }


    else {
      alert("Invalid Form Details");
    }

  };

  cancelButton(): void {

    this.router.navigate(['/homepage'])
  };

}
