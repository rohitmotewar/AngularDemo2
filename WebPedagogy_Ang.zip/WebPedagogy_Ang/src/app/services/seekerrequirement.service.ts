import { Injectable } from '@angular/core';

import { environment } from 'src/environments/environment';
import { Seekerrequirement } from 'src/app/models/seekerrequirement'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AddrequirementComponent } from '../components/addrequirement/addrequirement.component';
import { Seekerrequirement2 } from '../models/seekerrequirement2';
import { BehaviorSubject } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class SeekerrequirementService {

  private _apiUrl = `${environment.seekerrequirement.apiUrl}`;
  private _deleteReq = `${environment.seekerrequirement.deleteReq}`;
  private _updateReq = `${environment.seekerrequirement.updateReq}`;
  private _addReq = `${environment.seekerrequirement.addReq}`;
  private _approveReq = `${environment.seekerrequirement.approveRequirement}`;
  private _rejectReq = `${environment.seekerrequirement.rejectRequirement}`;

  constructor(private http: HttpClient) { }

  getRequirementList() {
    return this.http.get<Seekerrequirement2[]>(this._apiUrl);
  }//This is for to get all Req List

  public deleteRequirement(seekerrequirement: Seekerrequirement) {

    return this.http.delete(this._deleteReq + "/" + seekerrequirement.requirementId);
  }

  public updateRequirement(seekerrequirement: Seekerrequirement2) {

    //return this.http.post(this._updateReq,seekerrequirement, +"/"+seekerrequirement.requirementId+"/noofdays/"+seekerrequirement.noofdays+"/minBudget/"+seekerrequirement.minBudget+"/maxBudget"+seekerrequirement.maxBudget);
    // return this.http.post(this._updateReq, seekerrequirement)
    //return this.http.get<Seekerrequirement2>(this._updateReq + "/" + seekerrequirement.requirementId + "/noofdays/" + seekerrequirement.noofdays + "/minBudget/" + seekerrequirement.minBudget + "/maxBudget/" + seekerrequirement.maxBudget);
    return this.http.post<Seekerrequirement2>(this._updateReq, seekerrequirement);
  }

  public addRequirement(requirement: Seekerrequirement2) {
    return this.http.post<Seekerrequirement>(this._addReq, requirement)
  }

  public approveRequirement(requirement: Seekerrequirement2) {
    //alert("iam in approv service");
    return this.http.get<Seekerrequirement2>(this._approveReq + "/" + requirement.requirementId);

  }

  public rejectRequirement(requirement: Seekerrequirement2) {
    return this.http.get<Seekerrequirement2>(this._rejectReq + "/" + requirement.requirementId)

  }

}
