import { Component, OnInit } from '@angular/core';
import { Seekerrequirement } from 'src/app/models/Seekerrequirement';
import { SeekerrequirementService } from 'src/app/services/seekerrequirement.service';
import { Seekerrequirement2 } from 'src/app/models/seekerrequirement2';
import { Router } from '@angular/router';



@Component({
  selector: 'app-addrequirement',
  templateUrl: './addrequirement.component.html',
  styleUrls: ['./addrequirement.component.css']
})
export class AddrequirementComponent implements OnInit {
  requirement: Seekerrequirement2 = new Seekerrequirement2();


  constructor(private reqService: SeekerrequirementService, private router: Router) {


  }

  ngOnInit() {
  }

  addRequirement(): void {
    this.reqService.addRequirement(this.requirement).subscribe
      (data => {
        alert("Requirement Added")
        this.router.navigate(['/requirementlist'])
      });
  };

  cancelButton(): void {

    this.router.navigate(['/seekerhome'])
  };

}
