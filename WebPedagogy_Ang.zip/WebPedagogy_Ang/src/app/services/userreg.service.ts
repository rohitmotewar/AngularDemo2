import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Userreg } from '../models/userreg';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserregService {

  private _userReg = `${environment.userreg.userReg}`;
  private _getalluser = `${environment.userreg.getalluser}`;

  constructor(private http: HttpClient) { }


  public adduser(user: Userreg) {
    return this.http.post<Userreg>(this._userReg, user)
  }

}
