import { Component, OnInit } from '@angular/core';
import { SeekerrequirementService } from 'src/app/services/seekerrequirement.service';
import { Seekerrequirement } from 'src/app/models/seekerrequirement';
import { Seekerrequirement2 } from 'src/app/models/seekerrequirement2';
import { UpdatereqService } from 'src/app/services/updatereq.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-requirementlist',
  templateUrl: './requirementlist.component.html',
  styleUrls: ['./requirementlist.component.css'],
  providers: [SeekerrequirementService]

})
export class RequirementlistComponent implements OnInit {
  message: string;
  requirementList: Seekerrequirement2[];


  constructor(private rService: SeekerrequirementService, private updateService: UpdatereqService, private router: Router) { }

  ngOnInit() {

    this.rService.getRequirementList().subscribe(

      (data) => {
        console.log("Success", data);
        this.requirementList = data;
      },
      (err) => console.log("Error", err)

    )
  }

  deleteRequirement(requirement: Seekerrequirement): void {
    //alert("delete here" + requirement.requirementId)
    this.rService.deleteRequirement(requirement)
      .subscribe(data => {
        this.requirementList = this.requirementList.filter(r => r !== requirement);
        //window.location.reload(); //Refresh the page

      });
    alert("Record Deleted Successfully")
  }

  selectedReq: Seekerrequirement;

  onSelect(seekerrequirement: Seekerrequirement): void {
    this.selectedReq = seekerrequirement;
  }

  updateRequirement(seekerrequirement: Seekerrequirement2): void {
    this.updateService.changeReq(seekerrequirement);
    this.router.navigate(['/updaterequirement']);
    // alert("Record Updated")
  }

  approveRequirement(seekerrequirement: Seekerrequirement2): void {
    //alert('Approve here ' + seekerrequirement.requirementId);
    this.rService.approveRequirement(seekerrequirement)
      .subscribe(data => {
        this.requirementList = this.requirementList.filter(r => r !== seekerrequirement);
        alert('Requirement Approved');

      });

  }

  rejecteRequirement(seekerrequirement: Seekerrequirement2): void {
    //alert('Reject here ' + seekerrequirement.requirementId);
    this.rService.rejectRequirement(seekerrequirement)
      .subscribe(data => {
        this.requirementList = this.requirementList.filter(r => r !== seekerrequirement);
        alert('Requirement Rejected');
      });

  }



}
