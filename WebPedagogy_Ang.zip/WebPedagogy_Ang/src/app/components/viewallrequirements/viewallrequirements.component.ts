import { Component, OnInit } from '@angular/core';
import { SeekerrequirementService } from 'src/app/services/seekerrequirement.service';
import { Seekerrequirement } from 'src/app/models/seekerrequirement';
import { Seekerrequirement2 } from 'src/app/models/seekerrequirement2';
import { UpdatereqService } from 'src/app/services/updatereq.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallrequirements',
  templateUrl: './viewallrequirements.component.html',
  styleUrls: ['./viewallrequirements.component.css']
})
export class ViewallrequirementsComponent implements OnInit {
  requirementList: Seekerrequirement[];

  constructor(private rService: SeekerrequirementService, private updateService: UpdatereqService, private router: Router) { }

  ngOnInit() {

    this.rService.getRequirementList().subscribe(

      (data) => {
        console.log("Success", data);
        this.requirementList = data;
      },
      (err) => console.log("Error", err)

    )
  }

}
