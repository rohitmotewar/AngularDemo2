import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Seekerrequirement2 } from '../models/seekerrequirement2';

@Injectable({
  providedIn: 'root'
})
export class UpdatereqService {
  private messageSource = new BehaviorSubject('default message');

  private sReq = new BehaviorSubject<Seekerrequirement2>(null);

  //currentMessage = this.messageSource.asObservable();

  currentRequirement = this.sReq.asObservable();

  constructor() { }



  changeReq(seekerrequirement: Seekerrequirement2) {
    this.sReq.next(seekerrequirement);

  }

}
