import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateseekerprofileComponent } from './updateseekerprofile.component';

describe('UpdateseekerprofileComponent', () => {
  let component: UpdateseekerprofileComponent;
  let fixture: ComponentFixture<UpdateseekerprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateseekerprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateseekerprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
