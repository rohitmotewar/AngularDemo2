import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Userreg } from '../models/userreg';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  private _loginValidate = `${environment.userreg.loginValidate}`;
  private _getallSeeker = `${environment.userreg.getallseeker}`;
  private _getallProvider = `${environment.userreg.getallprovider}`;
  private _updateSeeker = `${environment.userreg.updateSeeker}`;
  private _updateProvider = `${environment.userreg.updateProvider}`;
  private _updateAdmin = `${environment.userreg.updateAdmin}`;
  private _deleteSeeker = `${environment.userreg.deleteSeeker}`;
  private _deleteProvider = `${environment.userreg.deleteProvider}`;

  constructor(private http: HttpClient) { }


  validateUser(user: Userreg) {
    // return this.http.post<Userreg>(this._loginValidate, user)
    return this.http.get<Userreg>(this._loginValidate + "/" + user.email + "/password/" + user.password + "/role/" + user.role);

  }

  getAllSeekers() {
    return this.http.get<Userreg[]>(this._getallSeeker);
  }

  getAllProviders() {
    return this.http.get<Userreg[]>(this._getallProvider);
  }




  updateSeeker(user: Userreg) {
    //alert("you are in UpdateSeeker service");
    return this.http.post<Userreg>(this._updateSeeker, user);
  }

  updateProvider(user: Userreg) {
    return this.http.post<Userreg>(this._updateProvider, user);
  }

  updateAdmin(user: Userreg) {
    return this.http.post<Userreg>(this._updateAdmin, user);
  }

  deleteSeeker(user: Userreg) {
    return this.http.post<Userreg>(this._deleteSeeker + "/" + user.email, user);
  }
  deleteProvider(user: Userreg) {
    return this.http.post<Userreg>(this._deleteProvider + "/" + user.email, user);
  }

}
