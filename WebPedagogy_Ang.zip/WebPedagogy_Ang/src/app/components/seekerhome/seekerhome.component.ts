import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-seekerhome',
  templateUrl: './seekerhome.component.html',
  styleUrls: ['./seekerhome.component.css']
})
export class SeekerhomeComponent implements OnInit {

  sData: Userreg;

  showHeader: boolean = false;


  constructor(private loginService: LoginuserService, private router: Router) {

  }


  ngOnInit() {
    this.loginService.currenMessage.subscribe(
      (data) => {
        this.sData = data;

      },
      (err) => console.log('error occured')

    )

  }

  signOut() {
    localStorage.clear();
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }

}
