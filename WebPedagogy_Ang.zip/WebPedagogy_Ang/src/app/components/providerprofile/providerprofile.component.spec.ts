import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProviderprofileComponent } from './providerprofile.component';

describe('ProviderprofileComponent', () => {
  let component: ProviderprofileComponent;
  let fixture: ComponentFixture<ProviderprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProviderprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
