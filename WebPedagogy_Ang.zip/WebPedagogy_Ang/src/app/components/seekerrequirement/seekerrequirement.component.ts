import { Component, OnInit, Input } from '@angular/core';
import { Seekerrequirement } from 'src/app/models/seekerrequirement';

@Component({
  selector: 'app-seekerrequirement',
  templateUrl: './seekerrequirement.component.html',
  styleUrls: ['./seekerrequirement.component.css']
})
export class SeekerrequirementComponent implements OnInit {

  @Input()
  requirementData: Seekerrequirement;

  constructor() { }

  ngOnInit() {
  }

}
