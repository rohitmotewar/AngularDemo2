import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerequirementComponent } from './managerequirement.component';

describe('ManagerequirementComponent', () => {
  let component: ManagerequirementComponent;
  let fixture: ComponentFixture<ManagerequirementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagerequirementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
