import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, RouterModule, NavigationStart } from '@angular/router';
import { Seeker } from 'src/app/models/seeker';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginserviceService } from 'src/app/services/loginservice.service';


@Component({
  selector: 'app-updateproviderprofile',
  templateUrl: './updateproviderprofile.component.html',
  styleUrls: ['./updateproviderprofile.component.css']
})
export class UpdateproviderprofileComponent implements OnInit {
  pData: Userreg;

  providerUpdateForm: FormGroup = new FormGroup(
    {
      role: new FormControl("", [Validators.required]),
      firstname: new FormControl("", [Validators.required]),
      lastname: new FormControl("", [Validators.required]),
      dob: new FormControl(""),
      phoneNo: new FormControl("", [Validators.required, Validators.minLength(10)]),
      email: new FormControl("", [Validators.required, Validators.email]),
      companyname: new FormControl(""),
      password: new FormControl("", [Validators.required, Validators.minLength(6)]),
      street: new FormControl(""),
      area: new FormControl(""),
      city: new FormControl(""),
      state: new FormControl(""),
      country: new FormControl(""),
      pancardNo: new FormControl(""),
      gstNo: new FormControl(""),
      subscription: new FormControl(""),
      provider_type: new FormControl("")


    });



  constructor(private loginService: LoginuserService, private loginServiceUpdt: LoginserviceService, private router: Router) { }

  ngOnInit() {

    this.loginService.currenMessage.subscribe(
      (data) => {
        this.pData = data;
        console.log("Success", data);
      },
      (err) => console.log('error occured')

    )

  }

  updateProvider(): void {
    alert("Update Requirement with Req.ID : " + this.pData.email);
    if (this.providerUpdateForm.valid) {

      this.loginServiceUpdt.updateProvider(this.pData).subscribe
        (data => {
          alert("User's Profile updated Successfully");
          this.router.navigate(['/providerprofile']);
        });
    }

  }

  cancelButton() {
    this.router.navigate(["/providerprofile"]);
  }

  signOut() {
    localStorage.clear();
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
}
