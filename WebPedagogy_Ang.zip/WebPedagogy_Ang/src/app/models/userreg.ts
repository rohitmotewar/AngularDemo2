export class Userreg {
    email: string;
    firstname: string;
    lastname: string;
    dob: string;
    companyname: string;
    phoneNo: string;
    password: string;
    role: string;
    street: string;
    area: string;
    city: string;
    state: string;
    country: string;
    pancardNo: string;
    gstNo: string;
    subscription: string;
    provider_type: string;


}
