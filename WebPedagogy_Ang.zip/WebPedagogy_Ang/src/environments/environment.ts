// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,

  seekerrequirement: {
    apiUrl: "http://192.168.1.123:8088/getallrequirements",
    deleteReq: "http://192.168.1.123:8088/deleterequirement/requirementId",
    updateReq: "http://192.168.1.123:8088/updateReq",
    addReq: "http://192.168.1.123:8088/addrequirement",
    userReg: "http://192.168.1.123:8088/adduser",
    getalluser: "http://192.168.1.123:8088/getallusers",
    approveRequirement: "http://192.168.1.123:8088/approverequirement/requirementId",
    rejectRequirement: "http://192.168.1.123:8088/rejectrequirement/requirementId"

  },


  userreg: {
    userReg: "http://192.168.1.123:8088/adduser",
    getalluser: "http://192.168.1.123:8088/getallusers",
    loginValidate: "http://192.168.1.123:8088/validateuser/email",
    getallseeker: "http://192.168.1.123:8088/getallseeker",
    getallprovider: "http://192.168.1.123:8088/getallprovider",
    updateSeeker: "http://192.168.1.123:8088/updateseeker",
    updateProvider: "http://192.168.1.123:8088/updateprovider",
    updateAdmin: "http://192.168.1.123:8088/updateadmin",
    deleteSeeker: "http://192.168.1.123:8088/deleteseeker/email",
    deleteProvider: "http://192.168.1.123:8088/deleteProvider/email"
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
