export const environment = {
  production: true,

  seekerrequirement: {
    apiUrl: "http://localhost:8088/getallrequirements",
    deleteReq: "http://localhost:8088/deleterequirement/requirementId",
    updateReq: "http://localhost:8088/updateReq",
    addReq: "http://localhost:8088/addrequirement",
    userReg: "http://localhost:8088/adduser",
    getalluser: "http://localhost:8088/getallusers",
    approveRequirement: "http://localhost:8088/approverequirement/requirementId",
    rejectRequirement: "http://localhost:8088/rejectrequirement/requirementId"

  },


  userreg: {
    userReg: "http://localhost:8088/adduser",
    getalluser: "http://localhost:8088/getallusers",
    loginValidate: "http://localhost:8088/validateuser/email",
    getallseeker: "http://localhost:8088/getallseeker",
    getallprovider: "http://localhost:8088/getallprovider",
    updateSeeker: "http://localhost:8088/updateseeker",
    updateProvider: "http://localhost:8088/updateprovider",
    updateAdmin: "http://localhost:8088/updateadmin",
    deleteSeeker: "http://localhost:8088/deleteseeker/email",
    deleteProvider: "http://192.168.1.123:8088/deleteProvider/email"
  }

};