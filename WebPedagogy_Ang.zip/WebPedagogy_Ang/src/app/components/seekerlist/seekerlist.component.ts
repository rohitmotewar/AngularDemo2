import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-seekerlist',
  templateUrl: './seekerlist.component.html',
  styleUrls: ['./seekerlist.component.css']
})
export class SeekerlistComponent implements OnInit {
  seekerList: Userreg[];

  constructor(private loginService: LoginserviceService, private router: Router) { }

  ngOnInit() {
    this.loginService.getAllSeekers().subscribe(
      (data) => {
        console.log("Success", data);
        this.seekerList = data;
      },
      (err) => console.log("Error", err)

    )

  }

  deleteSeeker(user: Userreg): void {
    this.loginService.deleteSeeker(user)
      .subscribe(data => {
        this.seekerList = this.seekerList.filter(r => r !== user);

      })

  }



}


