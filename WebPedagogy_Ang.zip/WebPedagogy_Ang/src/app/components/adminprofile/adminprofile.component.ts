import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {
  aData: Userreg;

  constructor(private loginService: LoginuserService, private router: Router) { }

  ngOnInit() {
    this.loginService.currenMessage.subscribe(
      (data) => {
        this.aData = data;

      },
      (err) => console.log('error occured')

    )
  }

  updateAdmin(admin: Userreg) {
    //alert("email is" + seeker.email)
    this.loginService.sendusertoHome(admin);
    this.router.navigate(['/updateadmin']);
  }

}
