

export class Seekerrequirement2 {

    module_Description: string;
    requirementId: string;
    noofdays: number;
    startday: string;
    minBudget: number;
    maxBudget: number;
    location: string;
    training_Level: string;
    takeaways: string;
    status: String;

}



