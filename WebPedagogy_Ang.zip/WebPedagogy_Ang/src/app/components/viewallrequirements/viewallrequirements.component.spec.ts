import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallrequirementsComponent } from './viewallrequirements.component';

describe('ViewallrequirementsComponent', () => {
  let component: ViewallrequirementsComponent;
  let fixture: ComponentFixture<ViewallrequirementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallrequirementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallrequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
