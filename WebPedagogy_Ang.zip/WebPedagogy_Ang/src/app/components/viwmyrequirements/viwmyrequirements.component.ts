import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viwmyrequirements',
  templateUrl: './viwmyrequirements.component.html',
  styleUrls: ['./viwmyrequirements.component.css']
})
export class ViwmyrequirementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
