import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-providerlist',
  templateUrl: './providerlist.component.html',
  styleUrls: ['./providerlist.component.css']
})
export class ProviderlistComponent implements OnInit {
  providerList: Userreg[];

  constructor(private loginService: LoginserviceService, private router: Router) { }

  ngOnInit() {

    this.loginService.getAllProviders().subscribe(
      (data) => {
        console.log("Success", data);
        this.providerList = data;
      },
      (err) => console.log("Error", err)

    )

  }


  deleteProvider(user: Userreg): void {
    this.loginService.deleteProvider(user)
      .subscribe(data => {
        this.providerList = this.providerList.filter(r => r !== user);

      })

  }

}


