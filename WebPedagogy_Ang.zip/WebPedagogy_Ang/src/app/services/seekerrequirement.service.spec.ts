import { TestBed } from '@angular/core/testing';

import { SeekerrequirementService } from './seekerrequirement.service';

describe('SeekerrequirementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SeekerrequirementService = TestBed.get(SeekerrequirementService);
    expect(service).toBeTruthy();
  });
});
