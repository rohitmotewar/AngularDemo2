import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-providerprofile',
  templateUrl: './providerprofile.component.html',
  styleUrls: ['./providerprofile.component.css']
})
export class ProviderprofileComponent implements OnInit {

  pData: Userreg;
  constructor(private loginService: LoginuserService, private router: Router) { }

  ngOnInit() {
    this.loginService.currenMessage.subscribe(
      (data) => {
        this.pData = data;

      },
      (err) => console.log('error occured')

    )
  }

  updateProvider(provider: Userreg) {
    //alert("email is" + seeker.email)
    this.loginService.sendusertoHome(provider);
    this.router.navigate(['/updateprovider']);
  }

}
