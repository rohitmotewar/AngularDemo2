import { Injectable } from '@angular/core';
import { Userreg } from '../models/userreg';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {
  private user: Userreg;
  private messagSource = new BehaviorSubject<Userreg>(this.user);
  currenMessage = this.messagSource.asObservable();


  constructor() { }

  sendusertoHome(user: Userreg) {
    this.user = user;
    this.messagSource.next(this.user);
  }
} 
