import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViwmyrequirementsComponent } from './viwmyrequirements.component';

describe('ViwmyrequirementsComponent', () => {
  let component: ViwmyrequirementsComponent;
  let fixture: ComponentFixture<ViwmyrequirementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViwmyrequirementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViwmyrequirementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
