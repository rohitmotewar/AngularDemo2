import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';
import { Seeker } from 'src/app/models/seeker';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginserviceService } from 'src/app/services/loginservice.service';

@Component({
  selector: 'app-updateadminprofile',
  templateUrl: './updateadminprofile.component.html',
  styleUrls: ['./updateadminprofile.component.css']
})
export class UpdateadminprofileComponent implements OnInit {
  aData: Userreg;

  adminUpdateForm: FormGroup = new FormGroup(
    {
      role: new FormControl("", [Validators.required]),
      firstname: new FormControl("", [Validators.required]),
      lastname: new FormControl("", [Validators.required]),
      email: new FormControl("", [Validators.required, Validators.email]),
      password: new FormControl("", [Validators.required])
    });

  constructor(private loginService: LoginuserService, private loginServiceUpdt: LoginserviceService, private router: Router) { }

  ngOnInit() {

    this.loginService.currenMessage.subscribe(
      (data) => {
        this.aData = data;
        console.log("Success", data);
      },
      (err) => console.log('error occured')

    )

  }

  updateAdmin(): void {
    alert("Update Requirement with Req.ID : " + this.aData.email);
    if (this.adminUpdateForm.valid) {

      this.loginServiceUpdt.updateAdmin(this.aData).subscribe
        (data => {
          alert("User's Profile updated Successfully");
          this.router.navigate(['/adminprofile'])
        });
    }


  }
  cancelButton(): void {
    this.router.navigate(["/adminprofile"])
  }
}

