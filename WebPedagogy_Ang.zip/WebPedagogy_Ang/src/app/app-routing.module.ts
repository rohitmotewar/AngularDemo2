import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule, Route } from '@angular/router';
import { RequirementlistComponent } from 'src/app/components/requirementlist/requirementlist.component';
import { AddrequirementComponent } from 'src/app/components/addrequirement/addrequirement.component';
import { UpdatereqComponent } from './components/updatereq/updatereq.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { UserregistrationComponent } from './components/userregistration/userregistration.component';
import { LoginComponent } from './components/login/login.component';
import { SeekerhomeComponent } from './components/seekerhome/seekerhome.component';
import { ProviderhomeComponent } from './components/providerhome/providerhome.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { SeekerprofileComponent } from './components/seekerprofile/seekerprofile.component';
import { ProviderprofileComponent } from './components/providerprofile/providerprofile.component';
import { UpdateseekerprofileComponent } from './components/updateseekerprofile/updateseekerprofile.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { UpdateproviderprofileComponent } from './components/updateproviderprofile/updateproviderprofile.component';
import { ViewallrequirementsComponent } from './components/viewallrequirements/viewallrequirements.component';
import { AdminprofileComponent } from './components/adminprofile/adminprofile.component';
import { SeekerlistComponent } from './components/seekerlist/seekerlist.component';
import { ProviderlistComponent } from './components/providerlist/providerlist.component';
import { ManagerequirementComponent } from './components/managerequirement/managerequirement.component';
import { UpdateadminprofileComponent } from './components/updateadminprofile/updateadminprofile.component';
import { ViwmyrequirementsComponent } from './components/viwmyrequirements/viwmyrequirements.component';


const routes: Route[] = [

  { path: '', redirectTo: '/homepage', pathMatch: 'full' },
  { path: 'homepage', component: HomepageComponent },
  { path: 'requirementlist', component: RequirementlistComponent },
  { path: 'viewallrequirement', component: ViewallrequirementsComponent },
  { path: 'addrequirement', component: AddrequirementComponent },
  { path: 'updaterequirement', component: UpdatereqComponent },
  { path: 'userreg', component: UserregistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: 'seekerhome', component: SeekerhomeComponent },
  { path: 'providerhome', component: ProviderhomeComponent },
  { path: 'adminhome', component: AdminhomeComponent },
  { path: 'seekerprofile', component: SeekerprofileComponent },
  { path: 'providerprofile', component: ProviderprofileComponent },
  { path: 'updateseeker', component: UpdateseekerprofileComponent },
  { path: 'updateprovider', component: UpdateproviderprofileComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: 'contactus', component: ContactusComponent },
  { path: 'adminprofile', component: AdminprofileComponent },
  { path: 'seekerlist', component: SeekerlistComponent },
  { path: 'providerlist', component: ProviderlistComponent },
  { path: 'managerequirement', component: ManagerequirementComponent },
  { path: 'updateadmin', component: UpdateadminprofileComponent },
  { path: 'viewmyreq', component: ViwmyrequirementsComponent }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
