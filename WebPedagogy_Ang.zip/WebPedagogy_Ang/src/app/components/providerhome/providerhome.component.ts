import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';


@Component({
  selector: 'app-providerhome',
  templateUrl: './providerhome.component.html',
  styleUrls: ['./providerhome.component.css']
})
export class ProviderhomeComponent implements OnInit {

  pData: Userreg;
  constructor(private loginService: LoginuserService, private router: Router) { }

  ngOnInit() {

    this.loginService.currenMessage.subscribe(
      (data) => {
        this.pData = data;

      },
      (err) => console.log('error occured')

    )

  }


}


