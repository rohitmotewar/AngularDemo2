import { TestBed } from '@angular/core/testing';

import { UpdatereqService } from './updatereq.service';

describe('UpdatereqService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UpdatereqService = TestBed.get(UpdatereqService);
    expect(service).toBeTruthy();
  });
});
