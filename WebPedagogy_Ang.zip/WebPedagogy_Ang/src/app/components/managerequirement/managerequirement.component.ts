import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managerequirement',
  templateUrl: './managerequirement.component.html',
  styleUrls: ['./managerequirement.component.css']
})
export class ManagerequirementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
