import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validator, Validators } from '@angular/forms';
import { Userreg } from 'src/app/models/userreg';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup = new FormGroup({
    email: new FormControl("", [Validators.required, Validators.email]),
    password: new FormControl("", [Validators.required]),
    role: new FormControl("", Validators.required)
  }, { updateOn: 'change' }
  );
  validate: Userreg;



  constructor(private loginService: LoginserviceService, private router: Router, private loginuserS: LoginuserService) { }

  ngOnInit() {
  }

  validateUser(): void {
    if (this.loginForm.valid) {
      this.loginService.validateUser(this.loginForm.value).subscribe(
        (data) => {
          console.log("Success", data);
          this.validate = data;
          this.loginuserS.sendusertoHome(data);

          if (this.loginForm.value.role == "Seeker") {
            console.log("Role:");
            this.router.navigate(["/seekerhome"]);
          }
          else if (this.loginForm.value.role == "Provider") {
            this.router.navigate(["/providerhome"]);
          }
          else if (this.loginForm.value.role == "Admin") {
            this.router.navigate(["/requirementlist"]);
          }
          else {
            alert("Invalid Credentials");
          }

        },
        (err) => console.log("Invalid Login Details", err),


      )
    }
    else {
      alert("Invalid Login Details");
    }
  }

  cancelButton(): void {
    this.router.navigate(['/homepage'])
  }

}
