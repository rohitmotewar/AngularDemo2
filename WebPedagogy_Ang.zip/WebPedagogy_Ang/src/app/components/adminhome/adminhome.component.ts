import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginserviceService } from 'src/app/services/loginservice.service';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';
import { Seekerrequirement2 } from 'src/app/models/seekerrequirement2';
import { SeekerrequirementService } from 'src/app/services/seekerrequirement.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {
  aData: Userreg;
  manageRequirement: Seekerrequirement2;
  constructor(private loginService: LoginuserService, private router: Router, private manageReqSer: SeekerrequirementService) { }

  ngOnInit() {

    this.loginService.currenMessage.subscribe(
      (data) => {
        this.aData = data;

      },
      (err) => console.log('error occured')

    )




  }

}
