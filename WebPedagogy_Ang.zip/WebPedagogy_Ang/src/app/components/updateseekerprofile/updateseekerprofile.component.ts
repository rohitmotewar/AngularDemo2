import { Component, OnInit } from '@angular/core';
import { Userreg } from 'src/app/models/userreg';
import { LoginuserService } from 'src/app/services/loginuser.service';
import { Router, NavigationStart } from '@angular/router';
import { Seeker } from 'src/app/models/seeker';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginserviceService } from 'src/app/services/loginservice.service';

@Component({
  selector: 'app-updateseekerprofile',
  templateUrl: './updateseekerprofile.component.html',
  styleUrls: ['./updateseekerprofile.component.css']
})
export class UpdateseekerprofileComponent implements OnInit {
  sData: Userreg;

  //userreg: Userreg = new Userreg();
  //selectedValue: string = '';

  seekerUpdateForm: FormGroup = new FormGroup(
    {
      role: new FormControl("", [Validators.required]),
      firstname: new FormControl("", [Validators.required]),
      lastname: new FormControl("", [Validators.required]),
      dob: new FormControl(""),
      phoneNo: new FormControl("", [Validators.required, Validators.minLength(10)]),
      email: new FormControl("", [Validators.required, Validators.email]),
      companyname: new FormControl(""),
      password: new FormControl("", [Validators.required, Validators.minLength(6)]),
      street: new FormControl(""),
      area: new FormControl(""),
      city: new FormControl(""),
      state: new FormControl(""),
      country: new FormControl("")


    });



  constructor(private loginService: LoginuserService, private loginServiceUpdt: LoginserviceService, private router: Router) { }

  ngOnInit() {

    this.loginService.currenMessage.subscribe(
      (data) => {
        this.sData = data;
        console.log("Success", data);
      },
      (err) => console.log('error occured')

    )

  }


  updateSeeker(): void {
    alert("Update Requirement with Req.ID : " + this.sData.email);
    if (this.seekerUpdateForm.valid) {

      this.loginServiceUpdt.updateSeeker(this.sData).subscribe
        (data => {
          alert("User's Profile updated Successfully");
          this.router.navigate(['/seekerprofile'])
        });
    }


  }
  cancelButton(): void {
    this.router.navigate(["/seekerprofile"])
  }
}
