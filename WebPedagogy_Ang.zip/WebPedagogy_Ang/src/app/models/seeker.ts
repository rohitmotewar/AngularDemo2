export class Seeker {

    email: string;
    firstname: string;
    lastname: string;
    companyname: string;
    phoneNo: string;
    password: string;
    role: string;
    street: string;
    area: string;
    city: string;
    state: string;
    country: string;

}
